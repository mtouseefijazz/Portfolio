import { Phone, Mail, MapPin, Github, Linkedin, Send } from 'lucide-react';
import { useReveal } from '@/lib/useReveal';
import { SectionHeading } from './About';
import type { Profile } from '@/lib/types';

export function Contact({ profile }: { profile: Profile | null }) {
  const { ref, visible } = useReveal();

  const phone = profile?.phone ?? '03223517968';
  const email = profile?.email ?? 'mtouseefijazz@gmail.com';
  const location = profile?.location ?? 'Pakistan';
  const github = profile?.github_url;
  const linkedin = profile?.linkedin_url;

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-5 sm:px-8 transition-all duration-700 ${
          visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <SectionHeading
          index="05"
          title="Get in touch"
          subtitle="Have a question or want to collaborate? I'd love to hear from you."
        />

        <div className="mt-12 grid lg:grid-cols-2 gap-6">
          {/* Contact cards */}
          <div className="space-y-4">
            <a
              href={`tel:${phone}`}
              className="group flex items-center gap-4 p-5 glass glass-hover rounded-2xl"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-300 group-hover:bg-emerald-500/20 transition-all">
                <Phone className="w-6 h-6" />
              </span>
              <div>
                <p className="text-xs text-slate-500">Phone</p>
                <p className="text-white font-medium font-[Sora]">{phone}</p>
              </div>
            </a>

            <a
              href={`mailto:${email}`}
              className="group flex items-center gap-4 p-5 glass glass-hover rounded-2xl"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-300 group-hover:bg-cyan-500/20 transition-all">
                <Mail className="w-6 h-6" />
              </span>
              <div className="min-w-0">
                <p className="text-xs text-slate-500">Email</p>
                <p className="text-white font-medium font-[Sora] truncate">{email}</p>
              </div>
            </a>

            <div className="flex items-center gap-4 p-5 glass rounded-2xl">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.04] text-slate-300">
                <MapPin className="w-6 h-6" />
              </span>
              <div>
                <p className="text-xs text-slate-500">Location</p>
                <p className="text-white font-medium font-[Sora]">{location}</p>
              </div>
            </div>

            {(github || linkedin) && (
              <div className="flex gap-3 pt-2">
                {github && (
                  <a
                    href={github}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-300 glass glass-hover rounded-xl"
                  >
                    <Github className="w-4 h-4" /> GitHub
                  </a>
                )}
                {linkedin && (
                  <a
                    href={linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-300 glass glass-hover rounded-xl"
                  >
                    <Linkedin className="w-4 h-4" /> LinkedIn
                  </a>
                )}
              </div>
            )}
          </div>

          {/* Quick message */}
          <div className="glass rounded-2xl p-7">
            <h3 className="text-lg font-semibold text-white font-[Sora]">Send a message</h3>
            <p className="text-sm text-slate-400 mt-1">
              This will open your email app with the message ready to send.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                const fd = new FormData(form);
                const subject = encodeURIComponent(
                  `Portfolio message from ${fd.get('name')}`
                );
                const body = encodeURIComponent(
                  `${fd.get('message')}\n\nFrom: ${fd.get('name')} (${fd.get('email')})`
                );
                window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
              }}
              className="mt-6 space-y-4"
            >
              <input
                name="name"
                required
                placeholder="Your name"
                className="w-full px-3.5 py-2.5 bg-ink-850 border border-white/10 rounded-xl text-sm text-white placeholder:text-slate-500 focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
              />
              <input
                name="email"
                type="email"
                required
                placeholder="Your email"
                className="w-full px-3.5 py-2.5 bg-ink-850 border border-white/10 rounded-xl text-sm text-white placeholder:text-slate-500 focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
              />
              <textarea
                name="message"
                rows={4}
                required
                placeholder="Your message"
                className="w-full px-3.5 py-2.5 bg-ink-850 border border-white/10 rounded-xl text-sm text-white placeholder:text-slate-500 focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all resize-none"
              />
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-ink-950 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-xl hover:from-emerald-300 hover:to-cyan-300 transition-all glow"
              >
                <Send className="w-4 h-4" /> Send message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
