import { useEffect, useRef, useState } from 'react';
import {
  X,
  FolderGit2,
  PenLine,
  UserCircle,
  Plus,
  Pencil,
  Trash2,
  ExternalLink,
  ImageIcon,
  Loader2,
  ArrowUpRight,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { uploadImage } from '@/lib/upload';
import type { Project, BlogPost, Profile } from '@/lib/types';

interface AdminPanelProps {
  open: boolean;
  onClose: () => void;
}

type Tab = 'overview' | 'projects' | 'blog' | 'profile';

export function AdminPanel({ open, onClose }: AdminPanelProps) {
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');
  const [projects, setProjects] = useState<Project[]>([]);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open && user) loadAll();
  }, [open, user]);

  const loadAll = async () => {
    setLoading(true);
    const [p, b, pr] = await Promise.all([
      supabase.from('projects').select('*').order('created_at', { ascending: false }),
      supabase.from('blog_posts').select('*').order('created_at', { ascending: false }),
      supabase.from('profile').select('*').limit(1).maybeSingle(),
    ]);
    setProjects((p.data ?? []) as Project[]);
    setPosts((b.data ?? []) as BlogPost[]);
    setProfile((pr.data ?? null) as Profile | null);
    setLoading(false);
  };

  if (!open || !user) return null;

  return (
    <div className="fixed inset-0 z-[70] animate-fade-in">
      <div className="absolute inset-0 bg-ink-950/90 backdrop-blur-md" onClick={onClose} />
      <div className="relative h-full flex flex-col">
        {/* Top bar */}
        <div className="border-b border-white/[0.06] bg-ink-900/80 backdrop-blur-xl">
          <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 text-ink-950 font-bold text-sm font-[Sora]">
                MP
              </span>
              <div>
                <p className="text-white font-medium font-[Sora] leading-tight">Admin Panel</p>
                <p className="text-xs text-slate-500 leading-tight">{user.email}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="flex items-center gap-1.5 px-3.5 py-2 text-sm text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.04] transition-all"
            >
              <X className="w-4 h-4" /> Close
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-6xl mx-auto px-5 sm:px-8 py-8 grid lg:grid-cols-[220px_1fr] gap-8">
            {/* Sidebar */}
            <aside className="lg:sticky lg:top-4 self-start">
              <nav className="flex lg:flex-col gap-1.5 overflow-x-auto scrollbar-hide">
                <TabBtn id="overview" tab={tab} setTab={setTab} icon={ArrowUpRight} label="Overview" />
                <TabBtn id="projects" tab={tab} setTab={setTab} icon={FolderGit2} label="Projects" count={projects.length} />
                <TabBtn id="blog" tab={tab} setTab={setTab} icon={PenLine} label="Blog posts" count={posts.length} />
                <TabBtn id="profile" tab={tab} setTab={setTab} icon={UserCircle} label="Profile" />
              </nav>
            </aside>

            {/* Content */}
            <div className="min-w-0">
              {loading ? (
                <div className="flex items-center justify-center py-24 text-slate-500">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : (
                <>
                  {tab === 'overview' && (
                    <Overview
                      projects={projects.length}
                      posts={posts.length}
                      profile={profile}
                      setTab={setTab}
                    />
                  )}
                  {tab === 'projects' && (
                    <ProjectsManager projects={projects} onChange={loadAll} />
                  )}
                  {tab === 'blog' && <BlogManager posts={posts} onChange={loadAll} />}
                  {tab === 'profile' && (
                    <ProfileManager profile={profile} onChange={loadAll} />
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TabBtn({
  id,
  tab,
  setTab,
  icon: Icon,
  label,
  count,
}: {
  id: Tab;
  tab: Tab;
  setTab: (t: Tab) => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  count?: number;
}) {
  const active = tab === id;
  return (
    <button
      onClick={() => setTab(id)}
      className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-sm whitespace-nowrap transition-all ${
        active
          ? 'bg-emerald-500/10 text-emerald-200 border border-emerald-500/25'
          : 'text-slate-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
      {count !== undefined && (
        <span className="ml-auto text-xs text-slate-500">{count}</span>
      )}
    </button>
  );
}

/* ─────────────── Overview ─────────────── */
function Overview({
  projects,
  posts,
  profile,
  setTab,
}: {
  projects: number;
  posts: number;
  profile: Profile | null;
  setTab: (t: Tab) => void;
}) {
  const stats = [
    { label: 'Projects', value: projects, tab: 'projects' as Tab, icon: FolderGit2 },
    { label: 'Blog posts', value: posts, tab: 'blog' as Tab, icon: PenLine },
  ];
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white font-[Sora]">Welcome back</h2>
        <p className="text-slate-400 mt-1">Manage your portfolio from one place.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {stats.map((s) => (
          <button
            key={s.label}
            onClick={() => setTab(s.tab)}
            className="group glass glass-hover rounded-2xl p-6 text-left perspective-near"
          >
            <div className="preserve-3d">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-300 mb-4">
                <s.icon className="w-6 h-6" />
              </span>
              <p className="text-3xl font-bold text-white font-[Sora]">{s.value}</p>
              <p className="text-sm text-slate-400 mt-1">{s.label}</p>
              <p className="text-xs text-emerald-300 mt-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                Manage <ArrowUpRight className="w-3 h-3" />
              </p>
            </div>
          </button>
        ))}
      </div>

      {profile && (
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/10 bg-ink-850">
              {profile.photo_url ? (
                <img src={profile.photo_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-xl font-bold gradient-text font-[Sora]">
                  {profile.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                </div>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-white font-medium font-[Sora] truncate">{profile.name}</p>
              <p className="text-sm text-emerald-300">{profile.tagline}</p>
              <p className="text-xs text-slate-500 mt-1 truncate">{profile.email}</p>
            </div>
          </div>
          <button
            onClick={() => setTab('profile')}
            className="mt-4 text-sm text-emerald-300 hover:text-emerald-200 flex items-center gap-1"
          >
            Edit profile <Pencil className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}

/* ─────────────── Projects manager ─────────────── */
function ProjectsManager({
  projects,
  onChange,
}: {
  projects: Project[];
  onChange: () => void;
}) {
  const [editing, setEditing] = useState<Project | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this project?')) return;
    const { error } = await supabase.from('projects').delete().eq('id', id);
    if (!error) onChange();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white font-[Sora]">Projects</h2>
        <button
          onClick={() => {
            setEditing(null);
            setCreating(true);
          }}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-ink-950 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-lg hover:from-emerald-300 hover:to-cyan-300 transition-all"
        >
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {projects.length === 0 ? (
        <EmptyHint text="No projects yet. Add your first one." />
      ) : (
        <div className="space-y-3">
          {projects.map((p) => (
            <div
              key={p.id}
              className="group flex items-center gap-4 p-4 glass glass-hover rounded-xl"
            >
              <div className="w-14 h-14 rounded-lg overflow-hidden bg-ink-850 shrink-0">
                {p.image_url ? (
                  <img src={p.image_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-700">
                    <ImageIcon className="w-5 h-5" />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-white font-medium truncate">{p.title}</p>
                {p.description && (
                  <p className="text-xs text-slate-500 truncate">{p.description}</p>
                )}
              </div>
              <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => {
                    setEditing(p);
                    setCreating(true);
                  }}
                  className="p-2 text-emerald-300 rounded-lg hover:bg-white/[0.06]"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(p.id)}
                  className="p-2 text-rose-300 rounded-lg hover:bg-white/[0.06]"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {creating && (
        <ProjectEditor
          project={editing}
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            onChange();
          }}
        />
      )}
    </div>
  );
}

function ProjectEditor({
  project,
  onClose,
  onSaved,
}: {
  project: Project | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(project?.title ?? '');
  const [description, setDescription] = useState(project?.description ?? '');
  const [imageUrl, setImageUrl] = useState(project?.image_url ?? '');
  const [projectUrl, setProjectUrl] = useState(project?.project_url ?? '');
  const [tags, setTags] = useState((project?.tags ?? []).join(', '));
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { url, error } = await uploadImage(file, 'projects');
    setUploading(false);
    if (url) setImageUrl(url);
    if (error) alert('Upload failed: ' + error);
  };

  const save = async () => {
    if (!title.trim()) return;
    setBusy(true);
    const payload = {
      title: title.trim(),
      description: description.trim() || null,
      image_url: imageUrl || null,
      project_url: projectUrl.trim() || null,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
      updated_at: new Date().toISOString(),
    };
    if (project) {
      await supabase.from('projects').update(payload).eq('id', project.id);
    } else {
      await supabase.from('projects').insert(payload);
    }
    setBusy(false);
    onSaved();
  };

  return (
    <ModalShell title={project ? 'Edit project' : 'New project'} onClose={onClose}>
      <div className="space-y-4">
        <Field label="Title">
          <input value={title} onChange={(e) => setTitle(e.target.value)} className={inp} placeholder="Project title" />
        </Field>
        <Field label="Description">
          <textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} className={`${inp} resize-none`} placeholder="Short description" />
        </Field>
        <Field label="Image">
          <UploadRow imageUrl={imageUrl} uploading={uploading} onPick={fileRef} onChange={handleImage} />
        </Field>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Project URL (optional)">
            <input value={projectUrl} onChange={(e) => setProjectUrl(e.target.value)} className={inp} placeholder="https://..." />
          </Field>
          <Field label="Tags (comma separated)">
            <input value={tags} onChange={(e) => setTags(e.target.value)} className={inp} placeholder="Python, SQL" />
          </Field>
        </div>
        <SaveRow busy={busy} onSave={save} onCancel={onClose} label={project ? 'Save changes' : 'Add project'} />
      </div>
    </ModalShell>
  );
}

/* ─────────────── Blog manager ─────────────── */
function BlogManager({ posts, onChange }: { posts: BlogPost[]; onChange: () => void }) {
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this post?')) return;
    const { error } = await supabase.from('blog_posts').delete().eq('id', id);
    if (!error) onChange();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white font-[Sora]">Blog posts</h2>
        <button
          onClick={() => {
            setEditing(null);
            setCreating(true);
          }}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-ink-950 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-lg hover:from-emerald-300 hover:to-cyan-300 transition-all"
        >
          <Plus className="w-4 h-4" /> Write
        </button>
      </div>

      {posts.length === 0 ? (
        <EmptyHint text="No posts yet. Write your first one." />
      ) : (
        <div className="space-y-3">
          {posts.map((p) => (
            <div key={p.id} className="group flex items-center gap-4 p-4 glass glass-hover rounded-xl">
              <div className="w-14 h-14 rounded-lg overflow-hidden bg-ink-850 shrink-0">
                {p.cover_url ? (
                  <img src={p.cover_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-700">
                    <ImageIcon className="w-5 h-5" />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-white font-medium truncate">{p.title}</p>
                {p.excerpt && <p className="text-xs text-slate-500 truncate">{p.excerpt}</p>}
                <p className="text-xs text-slate-600 mt-0.5">
                  {new Date(p.created_at).toLocaleDateString()}{' '}
                  {!p.published && <span className="text-amber-400">· Draft</span>}
                </p>
              </div>
              <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => {
                    setEditing(p);
                    setCreating(true);
                  }}
                  className="p-2 text-emerald-300 rounded-lg hover:bg-white/[0.06]"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(p.id)}
                  className="p-2 text-rose-300 rounded-lg hover:bg-white/[0.06]"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {creating && (
        <PostEditor
          post={editing}
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            onChange();
          }}
        />
      )}
    </div>
  );
}

function PostEditor({
  post,
  onClose,
  onSaved,
}: {
  post: BlogPost | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(post?.title ?? '');
  const [excerpt, setExcerpt] = useState(post?.excerpt ?? '');
  const [content, setContent] = useState(post?.content ?? '');
  const [coverUrl, setCoverUrl] = useState(post?.cover_url ?? '');
  const [published, setPublished] = useState(post?.published ?? true);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const slugify = (s: string) =>
    s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

  const handleImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { url, error } = await uploadImage(file, 'blog');
    setUploading(false);
    if (url) setCoverUrl(url);
    if (error) alert('Upload failed: ' + error);
  };

  const save = async () => {
    if (!title.trim()) return;
    setBusy(true);
    const payload = {
      title: title.trim(),
      slug: slugify(title),
      excerpt: excerpt.trim() || null,
      content: content.trim() || null,
      cover_url: coverUrl || null,
      published,
      updated_at: new Date().toISOString(),
    };
    if (post) {
      await supabase.from('blog_posts').update(payload).eq('id', post.id);
    } else {
      await supabase.from('blog_posts').insert(payload);
    }
    setBusy(false);
    onSaved();
  };

  return (
    <ModalShell title={post ? 'Edit post' : 'Write a new post'} onClose={onClose} wide>
      <div className="space-y-4">
        <Field label="Title">
          <input value={title} onChange={(e) => setTitle(e.target.value)} className={inp} placeholder="Post title" />
        </Field>
        <Field label="Excerpt">
          <textarea rows={2} value={excerpt} onChange={(e) => setExcerpt(e.target.value)} className={`${inp} resize-none`} placeholder="Short summary" />
        </Field>
        <Field label="Content">
          <textarea rows={8} value={content} onChange={(e) => setContent(e.target.value)} className={`${inp} resize-none`} placeholder="Write your post..." />
        </Field>
        <Field label="Cover image">
          <UploadRow imageUrl={coverUrl} uploading={uploading} onPick={fileRef} onChange={handleImage} />
        </Field>
        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} className="w-4 h-4 rounded accent-emerald-500" />
          Published (visible to visitors)
        </label>
        <SaveRow busy={busy} onSave={save} onCancel={onClose} label={post ? 'Save changes' : 'Publish'} />
      </div>
    </ModalShell>
  );
}

/* ─────────────── Profile manager ─────────────── */
function ProfileManager({
  profile,
  onChange,
}: {
  profile: Profile | null;
  onChange: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState({
    name: profile?.name ?? 'Muhammad Touseef Ejaz',
    tagline: profile?.tagline ?? 'Agentic & Generative AI Engineer',
    bio: profile?.bio ?? '',
    phone: profile?.phone ?? '03223517968',
    email: profile?.email ?? 'mtouseefijazz@gmail.com',
    location: profile?.location ?? 'Pakistan',
    github_url: profile?.github_url ?? '',
    linkedin_url: profile?.linkedin_url ?? '',
    photo_url: profile?.photo_url ?? '',
  });

  const handlePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { url, error } = await uploadImage(file, 'profile');
    setUploading(false);
    if (url) setDraft((d) => ({ ...d, photo_url: url }));
    if (error) alert('Upload failed: ' + error);
  };

  const save = async () => {
    setBusy(true);
    if (profile) {
      await supabase
        .from('profile')
        .update({ ...draft, updated_at: new Date().toISOString() })
        .eq('id', profile.id);
    } else {
      await supabase.from('profile').insert(draft);
    }
    setBusy(false);
    onChange();
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-white font-[Sora] mb-6">Profile</h2>
      <div className="glass rounded-2xl p-6 space-y-4">
        <Field label="Profile photo">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-white/10 bg-ink-850">
              {draft.photo_url ? (
                <img src={draft.photo_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-xl font-bold gradient-text font-[Sora]">
                  MTE
                </div>
              )}
            </div>
            <button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-2 px-3.5 py-2 text-sm text-slate-300 glass rounded-lg hover:bg-white/[0.06] disabled:opacity-60"
            >
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
              Upload photo
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
          </div>
        </Field>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Name">
            <input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className={inp} />
          </Field>
          <Field label="Tagline">
            <input value={draft.tagline} onChange={(e) => setDraft({ ...draft, tagline: e.target.value })} className={inp} />
          </Field>
        </div>
        <Field label="Bio">
          <textarea rows={4} value={draft.bio} onChange={(e) => setDraft({ ...draft, bio: e.target.value })} className={`${inp} resize-none`} placeholder="Tell visitors about yourself" />
        </Field>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Phone">
            <input value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} className={inp} />
          </Field>
          <Field label="Email">
            <input value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} className={inp} />
          </Field>
          <Field label="Location">
            <input value={draft.location} onChange={(e) => setDraft({ ...draft, location: e.target.value })} className={inp} />
          </Field>
          <Field label="GitHub URL">
            <input value={draft.github_url} onChange={(e) => setDraft({ ...draft, github_url: e.target.value })} className={inp} placeholder="https://github.com/..." />
          </Field>
          <Field label="LinkedIn URL">
            <input value={draft.linkedin_url} onChange={(e) => setDraft({ ...draft, linkedin_url: e.target.value })} className={inp} placeholder="https://linkedin.com/in/..." />
          </Field>
        </div>

        <SaveRow busy={busy} onSave={save} onCancel={onChange} label="Save profile" />
      </div>
    </div>
  );
}

/* ─────────────── Shared bits ─────────────── */
function EmptyHint({ text }: { text: string }) {
  return (
    <div className="glass rounded-2xl p-12 text-center text-slate-500">
      <p>{text}</p>
    </div>
  );
}

function ModalShell({
  title,
  onClose,
  children,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-ink-950/85 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative w-full ${wide ? 'max-w-2xl' : 'max-w-lg'} max-h-[90vh] overflow-y-auto glass rounded-2xl p-7 glow-strong scrollbar-hide`}>
        <button onClick={onClose} className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.06]">
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-xl font-semibold text-white font-[Sora] mb-6">{title}</h3>
        {children}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs text-slate-400 mb-1.5">{label}</span>
      {children}
    </label>
  );
}

function UploadRow({
  imageUrl,
  uploading,
  onPick,
  onChange,
}: {
  imageUrl: string;
  uploading: boolean;
  onPick: React.RefObject<HTMLInputElement | null>;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      {imageUrl && <img src={imageUrl} alt="" className="w-16 h-16 rounded-lg object-cover border border-white/10" />}
      <button
        type="button"
        onClick={() => onPick.current?.click()}
        disabled={uploading}
        className="flex items-center gap-2 px-3.5 py-2 text-sm text-slate-300 glass rounded-lg hover:bg-white/[0.06] disabled:opacity-60"
      >
        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
        Upload
      </button>
      <input
        ref={onPick as React.RefObject<HTMLInputElement>}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={onChange}
      />
    </div>
  );
}

function SaveRow({
  busy,
  onSave,
  onCancel,
  label,
}: {
  busy: boolean;
  onSave: () => void;
  onCancel: () => void;
  label: string;
}) {
  return (
    <div className="flex items-center gap-2 pt-2">
      <button
        onClick={onSave}
        disabled={busy}
        className="flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium text-ink-950 bg-emerald-400 rounded-lg hover:bg-emerald-300 disabled:opacity-60"
      >
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
        {label}
      </button>
      <button onClick={onCancel} className="px-4 py-2.5 text-sm text-slate-300 glass rounded-lg hover:bg-white/[0.06]">
        Cancel
      </button>
    </div>
  );
}

const inp =
  'w-full px-3.5 py-2.5 bg-ink-850 border border-white/10 rounded-xl text-sm text-white placeholder:text-slate-500 focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all';
