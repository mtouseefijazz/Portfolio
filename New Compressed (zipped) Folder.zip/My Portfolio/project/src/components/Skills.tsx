import { useReveal } from '@/lib/useReveal';
import { SectionHeading } from './About';
import { skills, tools, learning } from '@/lib/content';

export function Skills() {
  const { ref, visible } = useReveal();

  return (
    <section id="skills" className="relative py-24 sm:py-32">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-5 sm:px-8 transition-all duration-700 ${
          visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <SectionHeading
          index="02"
          title="Skills & Tools"
          subtitle="The technologies I use to explore, analyze, and visualize data."
        />

        {/* Skills grid */}
        <div className="mt-12">
          <p className="text-xs uppercase tracking-widest text-slate-500 mb-5">Skills</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((s, i) => (
              <div
                key={s.name}
                className="group glass card-3d rounded-2xl p-6 perspective-near"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="preserve-3d">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.03] border border-white/[0.06] group-hover:border-white/10 transition-all">
                    <s.icon className={`w-6 h-6 ${s.color}`} />
                  </span>
                  <div className="mt-4">
                    <h3 className="text-white font-medium font-[Sora]">{s.name}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">{s.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tools */}
        <div className="mt-12">
          <p className="text-xs uppercase tracking-widest text-slate-500 mb-5">Tools</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {tools.map((t) => (
              <div
                key={t.name}
                className="group glass card-3d rounded-2xl p-5 flex flex-col items-center text-center perspective-near"
              >
                <div className="preserve-3d">
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/[0.03] border border-white/[0.06] mb-3 group-hover:scale-110 transition-transform">
                    <t.icon className={`w-7 h-7 ${t.color}`} />
                  </span>
                  <h3 className="text-sm text-white font-medium font-[Sora]">{t.name}</h3>
                  <p className="text-xs text-slate-500 mt-1">{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Currently learning */}
        <div className="mt-12">
          <div className="flex items-center gap-2 mb-5">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75 animate-ping" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-amber-400" />
            </span>
            <p className="text-xs uppercase tracking-widest text-amber-300/80">
              Currently learning
            </p>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {learning.map((l) => (
              <div
                key={l.name}
                className="group relative overflow-hidden glass card-3d rounded-2xl p-6 perspective-near"
              >
                <div className="absolute -right-8 -top-8 w-24 h-24 rounded-full bg-amber-500/5 group-hover:bg-amber-500/10 transition-colors" />
                <div className="relative preserve-3d">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.03] border border-white/[0.06]">
                    <l.icon className={`w-6 h-6 ${l.color}`} />
                  </span>
                  <div className="mt-4">
                    <h3 className="text-white font-medium font-[Sora]">{l.name}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">{l.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
