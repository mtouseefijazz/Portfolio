import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import type { Profile } from '@/lib/types';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { About } from '@/components/About';
import { Skills } from '@/components/Skills';
import { Projects } from '@/components/Projects';
import { Blog } from '@/components/Blog';
import { Contact } from '@/components/Contact';
import { Footer } from '@/components/Footer';
import { AuthModal } from '@/components/AuthModal';
import { AdminPanel } from '@/components/AdminPanel';

function App() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  useEffect(() => {
    loadProfile();
  }, []);

  // When the owner signs in for the first time, make sure a profile row exists.
  useEffect(() => {
    if (user && !profile) seedProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const loadProfile = async () => {
    const { data } = await supabase
      .from('profile')
      .select('*')
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (data) setProfile(data as Profile);
  };

  const seedProfile = async () => {
    // Try to read again in case it was created since last check
    const { data: existing } = await supabase
      .from('profile')
      .select('*')
      .limit(1)
      .maybeSingle();
    if (existing) {
      setProfile(existing as Profile);
      return;
    }
    const { data } = await supabase
      .from('profile')
      .insert({
        name: 'Muhammad Touseef Ejaz',
        tagline: 'Agentic & Generative AI Engineer',
        phone: '03223517968',
        email: 'mtouseefijazz@gmail.com',
        location: 'Pakistan',
      })
      .select()
      .single();
    if (data) setProfile(data as Profile);
  };

  return (
    <div className="relative min-h-screen bg-ink-950 overflow-x-hidden">
      <Navbar
        onSignInClick={() => setAuthOpen(true)}
        onAdminClick={() => setAdminOpen(true)}
      />

      <main>
        <Hero
          profile={profile}
          onProfileUpdate={setProfile}
          onSignInRequired={() => setAuthOpen(true)}
        />
        <About profile={profile} onProfileUpdate={setProfile} />
        <Skills />
        <Projects />
        <Blog />
        <Contact profile={profile} />
      </main>

      <Footer name={profile?.name ?? 'Muhammad Touseef Ejaz'} />

      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
      <AdminPanel open={adminOpen} onClose={() => setAdminOpen(false)} />
    </div>
  );
}

export default App;
